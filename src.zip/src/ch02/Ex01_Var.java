package ch02;

public class Ex01_Var {
	public static void main(String args[]) {
		int a = 100; //정수형 변수 a에 100을 할당
		System.out.println(a);//a에 저장된 100을 출력
	}

}
