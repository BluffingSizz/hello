package ch02;

public class HelloExam2 {
	public static int min(int n, int m) {
		return n-m;
	}
	
	
	public static void main(String args[]) {
		int a = 30;
		int b = 6;
		char s = '!';
		System.out.println("=============================");
		System.out.println("Hi");
		System.out.println("My Name is 홍길동");
		System.out.println(min(a,b));
		System.out.println(s);
		System.out.println("=============================");
	}
}
