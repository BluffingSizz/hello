package ch02;

public class Interpret {
	public static void main(String args[]) {
		int a;//지역변수 선언만
		int b;
		int tot;
		
		a=1;//값을 할당(초기화)
	    b=2;
		tot = a + b;
		System.out.println(tot);
	}

}
