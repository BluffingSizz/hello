package ch02;

public class RealTypeEx {
	public static void main(String[] args) {
		double d = 0.1234;
		double e = 1234E-4;//1234ㅌ10-4dlamfh 0.1234와 동일
		float f = 0.1234f;//float형은 숫자 뒤에 반드시 F또는 f를 붙임
		double w = .1234;//0.1234
		
		System.out.println(d);
	    System.out.println(e);
	    System.out.println(f);
	    System.out.println(w);
	}

}
