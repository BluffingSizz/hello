package ch02;

public class Ex02_String {
	public static void main(String[] args) {
		String name = "홍길동";
		System.out.println("당신의 이름은 "+name+"입니다.");
	}

}
