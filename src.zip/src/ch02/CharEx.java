package ch02;

public class CharEx {
	//유니코드 변환기
	public static void main(String[] args) {
		char aValue = '\u0041';
		System.out.println("char형('\u0041'):"+aValue);
		char bValue = '\u0041';
		System.out.println("char형(\'\\u0041\'):"+bValue);
	}

}
