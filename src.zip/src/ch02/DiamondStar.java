package ch02;

public class DiamondStar {
	public static void main(String[] args) {
		System.out.println("   *   ");
		System.out.println("  ***  ");
		System.out.println(" ***** ");
		System.out.println("*******");
		System.out.println(" ***** ");
		System.out.println("  ***  ");
		System.out.println("   *   ");
	}

}
