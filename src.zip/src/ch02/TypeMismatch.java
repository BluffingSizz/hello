package ch02;

public class TypeMismatch {
	
	
	public static void main(String args[]) {
		byte n;//-128~127까지 정수 저장
		n = 100;
		System.out.println(n);
		
	}

}
