package ch02;

public class VarInitTest {
	public static void main(String args[]) {
		//인터프린터방식
		int index;//지역변수는 반드시 반드시 초기화를 해줘야한다.
		
		index = 1;
		
		index = index + 1;
		System.out.println("index : "+ index);
	}

}
