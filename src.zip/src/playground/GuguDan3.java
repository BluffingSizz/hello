package playground;

public class GuguDan3 {
	public static void main(String[] args) {
		for (int i = 1; i<10; i++) {
			for (int n =1; n<=9 ; n++ ) {
				System.out.print(i+ "*" +n+"="+i*n+"\t");
			}
			System.out.println();
		}
	}

}
