package ch01;

public class Hello5 {

	public static void main(String[] args) {
		System.out.println("=============================");
		System.out.println("이름:한대성");
		System.out.println("이메일:handaeseong12@gmail.com");
		System.out.println("hp:010-6763-7381");
		System.out.println("=============================");
		//sysout + Ctrl+space
		System.out.println();
	}
}