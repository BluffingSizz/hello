package ch01;

public class Hello {

	public static void main(String[] args) {
			// 주석 : 프로그램실행에는 영향을 미치지 않는다.
		    //Ctrl + s : 저장
		    //Ctrl + F11 : 컴파일+실행
            System.out.println("안녕하세요. 자바World");
	}

}
