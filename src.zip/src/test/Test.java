package test;

public class Test {
	public static void main(String[] args) {
		int a = 5;
		if(a == 300) 
			a = 500;
	    a = a+1;
		System.out.println(a);
	
	}
}