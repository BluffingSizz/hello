package ch04;

public class If_Exam {
	
	public static void main(String[] args) {
		int a = 5;
		if( a%2 == 0) {//a를 2로 나눈 나머지가 0이면
			System.out.println(a+":짝수입니다.");
		}else {
			System.out.println(a+":홀수입니다.");
		}
	}

}
