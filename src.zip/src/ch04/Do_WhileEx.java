package ch04;

public class Do_WhileEx {
	public static void main(String[] args) {
		int i =1;
		do {
			System.out.print(i);
			i++;
		}while(i<=10);//나중에 검사, ;반드시찍어야함
	}

}
