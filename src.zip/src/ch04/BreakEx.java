package ch04;

public class BreakEx {
	public static void main(String[] args) {
		int i =1;
		while(true ) {//무한반복
			System.out.println(i++);
			
		}
	}

}
