package ch04;

public class Start4Ex {
	public static void main(String[] args) {
		
	}

}
