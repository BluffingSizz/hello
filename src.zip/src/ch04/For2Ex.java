package ch04;

public class For2Ex {
	public static void main(String[] args) {
		for(int i =1; i<=5; i++) {
			System.out.println(i);
		}
		for(int i =1; i<=5; i++) {
			System.out.print(i);
		}
		System.out.println();
	}

}
