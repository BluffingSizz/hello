package ch04;

public class WhileEx {
	public static void main(String[] args) {
		int i=1;
		while (i<=10) {//i=11일때 빠져나감
			System.out.println(i++);
		}
	}

}
