package ch04;

public class For_Ex2 {
	
	public static void main(String[] args) {
		for(int i =0; i<5; i++) {
			System.out.println("i의 값은 : " + i);
		}
	}

}
