package ch04;

public class GuguDan {
	public static void main(String[] args) {
		int dan = 2;
		for(int n=1;n<=9;n++) {
			System.out.println(dan + "*"+ n + "=" + dan*n);
		}
	}

}
