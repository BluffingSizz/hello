package ch04;

public class ContinueEx2 {
	public static void main(String[] args) {
		for(int i=0; i<10; i++) {
			if(i%2==0) {
				continue;
				//짝수가 continue문을 만나 다음코드 skip
			}
			System.out.println("홀수값 : "+ i);
		}
	}

}
