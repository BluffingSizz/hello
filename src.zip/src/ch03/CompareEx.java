package ch03;

public class CompareEx {
	
	public static void main(String[] args) {
		int a = 65;
		char c = 'A';
		System.out.println( a == c); //비교연산자(Equal)
		System.out.println( a = c); //대입연산자
		System.out.println( 'A' != 65);//비교연산자(NotEqual)
		
	}

}
