package ch03;

public class AssignEx {
	
	public static void main(String[] args) {
		int a=3, b=5, c=7;
		a += 3; // a = a+3
		System.out.println(a);
		b /= 5; // b = b / 5
		System.out.println(b);
		c %= 2; // c = c % 2
		System.out.println(c);
	}

}
