package ch03;

public class AndOr {
	
	public static void main(String[] args) {
		int a =7;
		System.out.println( a > 5 && a < 0);//t && f => false
		System.out.println( a > 5 || a < 0);//t || f => true
	}

}
