package ch03;

public class StringEx {
	
	public static void main(String[] args) {
		String str = "Hello" + "java"; //문자열 연결기호 +
		System.out.println(str);
		str = 123 + "C"; // 숫자 + 문자열 => 숫자가 문자열로 변환
		System.out.println(str);
		
		
	}

}
