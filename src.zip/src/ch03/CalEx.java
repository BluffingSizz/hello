package ch03;

public class CalEx {
	
	public static void main(String[] args) {
		int a = 10;
		int b = 8;
		int c = a / b; //a를 b로 나눈 몫
		System.out.println(c);
		c = a % b ; //a를 b로 나눈 나머지
		System.out.println(c);
		
	}

}
